//
//  main.c
//  ftrScanAPI_Carbon
//
//  Copyright (c) 2003-2008 Futronic Technology Company Ltd. All rights reserved.
//

#include <Carbon/Carbon.h>
#include "ftrScanAPI.h"

enum
{
	kScan = 'Scan',
	kStop = 'Stop',
	kSave = 'Save',
	kExit = 'Exit',
	kFFD  = 'Ffdt',
	kInvert = 'Invr',
};


ControlID kScanCtrlID = { 'Scan', 1 };
ControlID kStopCtrlID = { 'Stop', 2 };
ControlID kExitCtrlID = { 'Exit', 4 };
ControlID kFFDCtrlID =  { 'Ffdt', 5 };
ControlID kMsgCtrlID = { 'MsgC', 6 };
ControlID kInvrCtrlID = { 'Invr', 7 };
ControlID kSaveCtrlID = { 'Save', 9 };


WindowRef                    window;
Rect						 windowBounds;	
EventLoopTimerRef			 timer;


void *hDevice = NULL;
FTRSCAN_IMAGE_SIZE ImageSize;
unsigned char *pImageBuffer = NULL;

int InitDevice();
void FreeDevice();


void ShowError( StringPtr lpszEror );
const char* GetErrorMsg( unsigned long nErrCode );
void SetMsgCtrl( const char* lpszEror );

void OnScan();
void OnStop();
void OnExit();
void OnFFD();
void OnInvert();
void OnSave();

void DrawImage();

static OSStatus        AppEventHandler( EventHandlerCallRef inCaller, EventRef inEvent, void* inRefcon );
static OSStatus        HandleNew();
static OSStatus        WindowEventHandler( EventHandlerCallRef inCaller, EventRef inEvent, void* inRefcon );
static pascal void	   TimerCallback( EventLoopTimerRef inTimer,	void* inUserData );

void SaveNavEventProc( NavEventCallbackMessage callBackSelector, NavCBRecPtr callBackParms, void *callBackUserData );
void SaveImageToFile(NavReplyRecord* reply);

void SaveImageBuffer(FSRef* saveFileRef, unsigned char *pImage, int width, int height );

NavEventUPP gEventProc = NULL;

static IBNibRef        sNibRef;

//--------------------------------------------------------------------------------------------
int main(int argc, char* argv[])
{
    OSStatus                    err;
    static const EventTypeSpec    kAppEvents[] =
    {
        { kEventClassCommand, kEventCommandProcess }
    };
	
	
	if( !InitDevice() )
	{
		FreeDevice();
		return 0;
	}
	

    // Create a Nib reference, passing the name of the nib file (without the .nib extension).
    // CreateNibReference only searches into the application bundle.
    err = CreateNibReference( CFSTR("main"), &sNibRef );
    require_noerr( err, CantGetNibRef );
    
     
    // Install our handler for common commands on the application target
    InstallApplicationEventHandler( NewEventHandlerUPP( AppEventHandler ),
                                    GetEventTypeCount( kAppEvents ), kAppEvents,
                                    0, NULL );
    
    // Create a new window. A full-fledged application would do this from an AppleEvent handler
    // for kAEOpenApplication.
    HandleNew();
	
	    
    // Run the event loop
    RunApplicationEventLoop();

CantSetMenuBar:
CantGetNibRef:
	
	FreeDevice();
    return err;
}

//--------------------------------------------------------------------------------------------
static OSStatus
AppEventHandler( EventHandlerCallRef inCaller, EventRef inEvent, void* inRefcon )
{
    OSStatus    result = eventNotHandledErr;
    
    switch ( GetEventClass( inEvent ) )
    {
        case kEventClassCommand:
        {
            HICommandExtended cmd;
            verify_noerr( GetEventParameter( inEvent, kEventParamDirectObject, typeHICommand, NULL, sizeof( cmd ), NULL, &cmd ) );
            
            switch ( GetEventKind( inEvent ) )
            {
                case kEventCommandProcess:
                    switch ( cmd.commandID )
                    {
                        case kHICommandNew:
                            //result = HandleNew();
                            break;
                            
                        // Add your own command-handling cases here
                        
                        default:
                            break;
                    }
                    break;
            }
            break;
        }
            
        default:
            break;
    }
    
    return result;
}

//--------------------------------------------------------------------------------------------
DEFINE_ONE_SHOT_HANDLER_GETTER( WindowEventHandler )

//--------------------------------------------------------------------------------------------
static OSStatus
HandleNew()
{
    OSStatus                    err;
	static const EventTypeSpec    kWindowEvents[] =
    {
        { kEventClassCommand, kEventCommandProcess }
    };
	
	
    
    // Create a window. "MainWindow" is the name of the window object. This name is set in 
    // InterfaceBuilder when the nib is created.
    err = CreateWindowFromNib( sNibRef, CFSTR("MainWindow"), &window );
    require_noerr( err, CantCreateWindow );

    // Install a command handler on the window. We don't use this handler yet, but nearly all
    // Carbon apps will need to handle commands, so this saves everyone a little typing.
    InstallWindowEventHandler( window, GetWindowEventHandlerUPP(),
                               GetEventTypeCount( kWindowEvents ), kWindowEvents,
                               window, NULL );
							   
	err = GetWindowBounds( window, kWindowContentRgn, &windowBounds );
	require_noerr( err, CantCreateWindow );
	
	
	Rect						 windowNewBounds;
	windowNewBounds.right = windowBounds.right + ImageSize.nWidth;
	windowNewBounds.bottom = windowBounds.top + ImageSize.nHeight;
	windowNewBounds.top = windowBounds.top;
	windowNewBounds.left = windowBounds.left;
	
	
	err = SetWindowBounds( window, kWindowContentRgn, &windowNewBounds );
	require_noerr( err, CantCreateWindow );
							   
	
    
    // Position new windows in a staggered arrangement on the main screen
    //RepositionWindow( window, NULL, kWindowCascadeOnMainScreen );
    
    // The window was created hidden, so show it
    ShowWindow( window );
    
CantCreateWindow:
    return err;
}

//--------------------------------------------------------------------------------------------
static OSStatus
WindowEventHandler( EventHandlerCallRef inCaller, EventRef inEvent, void* inRefcon )
{
    OSStatus    err = eventNotHandledErr;
    
    switch ( GetEventClass( inEvent ) )
    {
        case kEventClassCommand:
        {
            HICommandExtended cmd;
            verify_noerr( GetEventParameter( inEvent, kEventParamDirectObject, typeHICommand, NULL, sizeof( cmd ), NULL, &cmd ) );
            
            switch ( GetEventKind( inEvent ) )
            {
                case kEventCommandProcess:
                    switch ( cmd.commandID )
                    {
                        // Add your own command-handling cases here
                        case kScan:
							OnScan();
							break;
						
						case kStop:
							OnStop();
							break;
											
						case kExit:			
							OnExit();				
							break;
							
						case kFFD:
							OnFFD();
							break;
							
						case kInvert:
							OnInvert();
							break;
							
						case kSave:
							OnSave();
							break;
													
                        default:
                            break;
                    }
                    break;
            }
            break;
        }
            
        default:
            break;
    }
    
    return err;
}


void OnScan()
{
	ControlRef StopCtrl;
	GetControlByID( window, &kStopCtrlID, &StopCtrl );

	ControlRef ScanCtrl;
	GetControlByID( window, &kScanCtrlID, &ScanCtrl );
	
	ControlRef saveCtrl;
	GetControlByID( window, &kSaveCtrlID, &saveCtrl );
	
	DisableControl( ScanCtrl );
	DisableControl( saveCtrl );
	EnableControl( StopCtrl );
	
	SetMsgCtrl( "Put finger on scaner" );
	
	InstallEventLoopTimer( GetCurrentEventLoop(), 100 * kEventDurationMillisecond,
			100 * kEventDurationMillisecond, TimerCallback, window, &timer );	
}


void OnStop()
{
	if( timer )
	{
		RemoveEventLoopTimer( timer );
		timer = NULL;
	}
	
	ControlRef StopCtrl;
	GetControlByID( window, &kStopCtrlID, &StopCtrl );

	ControlRef ScanCtrl;
	GetControlByID( window, &kScanCtrlID, &ScanCtrl );
	
	ControlRef saveCtrl;
	GetControlByID( window, &kSaveCtrlID, &saveCtrl );
		
	EnableControl( ScanCtrl );
	EnableControl( saveCtrl );
	DisableControl( StopCtrl );
	
	SetMsgCtrl( "" );	
	
}

void OnExit()
{
	QuitApplicationEventLoop();
}

void OnFFD()
{
	ControlRef FFDCtrl;
	GetControlByID( window, &kFFDCtrlID, &FFDCtrl );
	
	if( GetControlValue( FFDCtrl ) == kControlCheckBoxCheckedValue )
	{
		if( !ftrScanSetOptions( hDevice,
								FTR_OPTIONS_CHECK_FAKE_REPLICA,
								FTR_OPTIONS_CHECK_FAKE_REPLICA ) )
		{	
			SetMsgCtrl( GetErrorMsg( ftrScanGetLastError() ) );
		}
	}
	else
	{
		if( !ftrScanSetOptions( hDevice,
								FTR_OPTIONS_CHECK_FAKE_REPLICA,
								0 ) )
		{	
			SetMsgCtrl( GetErrorMsg( ftrScanGetLastError() ) );
		}
	}
}

void OnInvert()
{
	ControlRef InvertCtrl;
	GetControlByID( window, &kInvrCtrlID, &InvertCtrl );
	
	if( GetControlValue( InvertCtrl ) == kControlCheckBoxCheckedValue )
	{
		if( !ftrScanSetOptions( hDevice,
							   FTR_OPTIONS_INVERT_IMAGE, FTR_OPTIONS_INVERT_IMAGE ) )
		{	
			SetMsgCtrl( GetErrorMsg( ftrScanGetLastError() ) );
		}
	}
	else
	{
		if( !ftrScanSetOptions( hDevice,
							   FTR_OPTIONS_INVERT_IMAGE, 0 ) )
		{	
			SetMsgCtrl( GetErrorMsg( ftrScanGetLastError() ) );
		}
	}
}

void OnSave()
{
	OSStatus err = noErr;
	NavDialogRef saveDlg;
	NavDialogCreationOptions dlgOpt;
	
	if( ( err = NavGetDefaultDialogCreationOptions( &dlgOpt ) ) == noErr )
	{
		dlgOpt.parentWindow = window;
		dlgOpt.modality = kWindowModalityWindowModal;
		
		gEventProc = NewNavEventUPP( SaveNavEventProc );
		
		if( ( err = NavCreatePutFileDialog(&dlgOpt, 0, 0, gEventProc, NULL, &saveDlg ) ) == noErr )
		{
			if( saveDlg != NULL )
			{
				if(( err = NavDialogRun(saveDlg)) != noErr )
				{
					NavDialogDispose(saveDlg);
					DisposeNavEventUPP( gEventProc );
				}
			}
		}
		
		if(dlgOpt.saveFileName != NULL)
		{
			CFRelease(dlgOpt.saveFileName);
		}
	}
}

int InitDevice()
{
	int Result = 0;
	hDevice = ftrScanOpenDevice();
	
	if( hDevice )
	{
		if( ftrScanGetImageSize( hDevice, &ImageSize ) )
		{
			pImageBuffer = (unsigned char *)malloc( ImageSize.nImageSize );
			
			if( pImageBuffer )
			{
				Result = 1;
			}
			else
			{
				ShowError( "\pNo memory for image buffer" );	
			}
		}
		else
		{
			ShowError("\pFailed to get image size");
		}
		
		if( !ftrScanSetOptions( hDevice,
							   FTR_OPTIONS_INVERT_IMAGE, FTR_OPTIONS_INVERT_IMAGE ) )
		{	
			SetMsgCtrl( GetErrorMsg( ftrScanGetLastError() ) );
		}
	}
	else
	{
		ShowError("\pFailed to open device");
	}
	
	return Result;
}

void FreeDevice()
{
	if( hDevice )
	{
		ftrScanCloseDevice( hDevice );
		hDevice = NULL;
	}
	
	if( pImageBuffer )
	{
		free( pImageBuffer );
		pImageBuffer = NULL;
	}
}

void ShowError( StringPtr lpszError )
{
    SInt16 Result;	
	StandardAlert( kAlertStopAlert,"\pError", lpszError, NULL, &Result );
	 
}

pascal void	 TimerCallback( EventLoopTimerRef inTimer,	void* inUserData )
{
	//if( ftrScanIsFingerPresent( hDevice, NULL ) )
	//{				
		if( ftrScanGetFrame( hDevice, pImageBuffer, NULL) )
		{
	//		SetMsgCtrl( "Begin draw" );
			DrawImage();
			SetMsgCtrl( "OK" );
		}
		else
		{
			SetMsgCtrl( GetErrorMsg( ftrScanGetLastError() ) );
		}
	//}
	//else
	//{
	//	SetMsgCtrl( GetErrorMsg( FTR_ERROR_EMPTY_FRAME ) );
	//}
}

void DrawImage()
{
	CGColorSpaceRef grayColorSpace = CGColorSpaceCreateDeviceGray();	
		
	CGContextRef context;
	CGDataProviderRef provider;
	CGImageRef image;
	CGRect rect;
	
	QDBeginCGContext( GetWindowPort( window ), &context );
	
	provider = CGDataProviderCreateWithData(NULL, pImageBuffer, ImageSize.nImageSize, NULL);
	
	image = CGImageCreate( 		
		ImageSize.nWidth,
		ImageSize.nHeight, 
		8, 
		8,
		1 * ImageSize.nWidth, 
		grayColorSpace, 
		kCGBitmapByteOrderDefault, 
		provider, 
		NULL, 
		0, 
		kCGRenderingIntentDefault );
	
	CGColorSpaceRelease(grayColorSpace);
	
	rect = CGRectMake( 
		windowBounds.right - windowBounds.left, 
		0,
		ImageSize.nWidth,
		ImageSize.nHeight );
	
	CGContextDrawImage(context, rect, image);
	CGImageRelease(image);
	
	CGDataProviderRelease(provider);
	
	QDEndCGContext( GetWindowPort( window ), &context );
}

const char* GetErrorMsg( unsigned long nErrCode )
{
    switch( nErrCode ) 
	{
    case 0:
        return "OK";
        break;
		
    case FTR_ERROR_EMPTY_FRAME:	// ERROR_EMPTY
        return "- Empty frame -";
        break;
		
    case FTR_ERROR_MOVABLE_FINGER:
        return "- Movable finger -";
        break;
		
    case FTR_ERROR_NO_FRAME:
        return "- No frame -";
        break;
		
    case FTR_ERROR_USER_CANCELED:
        return "- User canceled -";
        break;
		
    case FTR_ERROR_HARDWARE_INCOMPATIBLE:
        return "- Incompatible hardware -";
        break;
		
    case FTR_ERROR_FIRMWARE_INCOMPATIBLE:
        return "- Incompatible firmware -";
        break;
		
    case FTR_ERROR_INVALID_AUTHORIZATION_CODE:
        return "- Invalid authorization code -";
        break;
    default:
        return "- Unknown return code -";
	}
	
	return "";
}

void SetMsgCtrl( const char* lpszText )
{
	ControlRef MsgCtrl;
	GetControlByID( window, &kMsgCtrlID, &MsgCtrl );
	
	CFStringRef Text = __CFStringMakeConstantString( lpszText );
	SetControlData( MsgCtrl, 0, kControlStaticTextCFStringTag, sizeof(CFStringRef), &Text );
}

void SaveNavEventProc( NavEventCallbackMessage callBackSelector, NavCBRecPtr callBackParms, void *callBackUserData )
{
	OSStatus status;
	switch (callBackSelector) 
	{
		case kNavCBUserAction: 
		{
			NavReplyRecord reply; 
			NavUserAction userAction = 0; 
			
			if ((status = NavDialogGetReply (callBackParms->context, &reply)) == noErr )
			{
				OSStatus tempErr;
				userAction = NavDialogGetUserAction(callBackParms->context);
				switch (userAction)
				{
					case kNavUserActionSaveAs:
					    SaveImageToFile(&reply);
						break;
				}
				
				tempErr = NavDisposeReply (&reply);
				if(!status)
				{		
					status = tempErr;
				}
			}
		}
	}
}

void SaveImageToFile(NavReplyRecord* reply)
{
	OSErr err = noErr;
	FSRef fileRefParent;
	AEDesc actualDesc;
	
	if(( err = AECoerceDesc( &reply->selection, typeFSRef, &actualDesc ) ) == noErr )
	{
		if(( err = AEGetDescData( &actualDesc, (void*)&fileRefParent, sizeof(FSRef))) == noErr )
		{
			UniChar* nameBuffer = NULL;
			CFIndex sourceLenght = 0;
			
			sourceLenght = CFStringGetLength(reply->saveFileName);
			nameBuffer = (UniChar*)NewPtr(sourceLenght*2);
			
			if(nameBuffer != NULL)
			{
				CFStringGetCharacters( reply->saveFileName, CFRangeMake(0, sourceLenght), &nameBuffer[0] );
				if(reply->replacing)
				{
					FSRef fileToDelete; 
					if((err = FSMakeFSRefUnicode(&fileRefParent,sourceLenght, nameBuffer,kTextEncodingUnicodeDefault, &fileToDelete ) ) == noErr )
					{
						err = FSDeleteObject(&fileToDelete);
					}
				}
				
				if( err == noErr )
				{
					FSRef saveFileRef;
										
					if( ( err = FSCreateFileUnicode(
									&fileRefParent, 
									sourceLenght, 
									nameBuffer, 
									kFSCatInfoNone, 
									NULL, 
									&saveFileRef,
									NULL ) ) == noErr )
					{
						SaveImageBuffer(&saveFileRef, pImageBuffer, ImageSize.nWidth, ImageSize.nHeight);
					}
				}
				
				DisposePtr((Ptr)nameBuffer);
			}
			
			AEDisposeDesc(&actualDesc);
		}		
	}
}

typedef struct tagBITMAPINFOHEADER{
        unsigned int	biSize;
        int				biWidth;
        int				biHeight;
        unsigned short int  biPlanes;
        unsigned short int	biBitCount;
        unsigned int	biCompression;
        unsigned int	biSizeImage;
        int			biXPelsPerMeter;
        int			biYPelsPerMeter;
        unsigned int   biClrUsed;
        unsigned int	biClrImportant;
} BITMAPINFOHEADER, *PBITMAPINFOHEADER;

typedef struct tagRGBQUAD {
        unsigned char	rgbBlue;
        unsigned char	rgbGreen;
        unsigned char	rgbRed;
        unsigned char	rgbReserved;
} RGBQUAD;

typedef struct tagBITMAPINFO {
    BITMAPINFOHEADER    bmiHeader;
    RGBQUAD             bmiColors[1];
} BITMAPINFO, *PBITMAPINFO;

typedef struct tagBITMAPFILEHEADER {
        unsigned short int	bfType;
        unsigned int	bfSize;
        unsigned short int	bfReserved1;
        unsigned short int	bfReserved2;
        unsigned int	bfOffBits;
} BITMAPFILEHEADER, *PBITMAPFILEHEADER;

void SaveImageBuffer(FSRef* saveFileRef, unsigned char *pImage, int width, int height )
{
	HFSUniStr255 forkName;
	SInt16 forkRefNum;
	OSStatus err;
		
	err = FSGetDataForkName(&forkName);
	
	if( ( err = FSOpenFork(saveFileRef, (UniCharCount)forkName.length,forkName.unicode,fsRdWrPerm,&forkRefNum))== noErr )
	{
		BITMAPINFO *pDIBHeader;
		BITMAPFILEHEADER  bmfHeader;
		int iCyc;
	
		unsigned char *cptrData;
		unsigned char *cptrDIBData;
		unsigned char *pDIBData;

		// allocate memory for a DIB header
		if( (pDIBHeader = (BITMAPINFO *)malloc( sizeof( BITMAPINFO ) + sizeof( RGBQUAD ) * 255 )) == NULL )
		{
			FSCloseFork(forkRefNum);
			return;
		}
		
		memset( (void *)pDIBHeader, 0, sizeof( BITMAPINFO ) + sizeof( RGBQUAD ) * 255 );
		
		// fill the DIB header
		pDIBHeader->bmiHeader.biSize          = sizeof( BITMAPINFOHEADER );
		pDIBHeader->bmiHeader.biWidth         = width;
		pDIBHeader->bmiHeader.biHeight        = height;
		pDIBHeader->bmiHeader.biPlanes        = 1;
		pDIBHeader->bmiHeader.biBitCount      = 8;		// 8bits gray scale bmp
		pDIBHeader->bmiHeader.biCompression   = 0;		// BI_RGB = 0;	
		// initialize logical and DIB grayscale
		for( iCyc = 0; iCyc < 256; iCyc++ )
		{
			pDIBHeader->bmiColors[iCyc].rgbBlue = pDIBHeader->bmiColors[iCyc].rgbGreen = pDIBHeader->bmiColors[iCyc].rgbRed = (unsigned char)iCyc;
		}
		
		bmfHeader.bfType = 0x42 + 0x4D * 0x100;
		bmfHeader.bfSize = 14 + sizeof( BITMAPINFO ) + sizeof( RGBQUAD ) * 255 + width * height;	//sizeof( BITMAPFILEHEADER ) = 14
		bmfHeader.bfReserved1 = bmfHeader.bfReserved2 = 0;
		bmfHeader.bfOffBits = 14 + pDIBHeader->bmiHeader.biSize + sizeof( RGBQUAD ) * 256;

		FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(unsigned short int), (void *)&bmfHeader.bfType, NULL );
		FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(unsigned int), (void *)&bmfHeader.bfSize, NULL );
		FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(unsigned short int), (void *)&bmfHeader.bfReserved1, NULL);
		FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(unsigned short int), (void *)&bmfHeader.bfReserved2, NULL );
		FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(unsigned int), (void *)&bmfHeader.bfOffBits, NULL );

		FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(unsigned  int), (void *)&pDIBHeader->bmiHeader.biSize, NULL);
		FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(int), (void *)&pDIBHeader->bmiHeader.biWidth, NULL);
		FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(int), (void *)&pDIBHeader->bmiHeader.biHeight, NULL);
		FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(unsigned short int), (void *)&pDIBHeader->bmiHeader.biPlanes, NULL);
		FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(unsigned short int), (void *)&pDIBHeader->bmiHeader.biBitCount, NULL);
		FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(unsigned int), (void *)&pDIBHeader->bmiHeader.biCompression, NULL);
		FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(unsigned int), (void *)&pDIBHeader->bmiHeader.biSizeImage, NULL);
		FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(int), (void *)&pDIBHeader->bmiHeader.biXPelsPerMeter, NULL);
		FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(int), (void *)&pDIBHeader->bmiHeader.biYPelsPerMeter, NULL);
		FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(unsigned int), (void *)&pDIBHeader->bmiHeader.biClrUsed, NULL);
		FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(unsigned int), (void *)&pDIBHeader->bmiHeader.biClrImportant, NULL);

		for( iCyc=0; iCyc<256; iCyc++ )
		{
			FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(unsigned char), (void *)&pDIBHeader->bmiColors[iCyc].rgbBlue, NULL );
			FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(unsigned char), (void *)&pDIBHeader->bmiColors[iCyc].rgbGreen, NULL );
			FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(unsigned char), (void *)&pDIBHeader->bmiColors[iCyc].rgbRed, NULL );
			FSWriteFork(forkRefNum, fsAtMark, 0, sizeof(unsigned char), (void *)&pDIBHeader->bmiColors[iCyc].rgbReserved, NULL );
		}
		
		//
	    //copy fingerprint image
		//
		pDIBData = (unsigned char*)malloc( height * width);
		
		if(!pDIBData)
		{
			free( pDIBHeader );
			FSCloseFork(forkRefNum);
		}
		
		memset( (void *)pDIBData, 0, height * width );

		cptrData = pImage + (height - 1) * width;
		cptrDIBData = pDIBData;
		for( iCyc = 0; iCyc < height; iCyc++ )
		{
			memcpy( cptrDIBData, cptrData, width );
			cptrData = cptrData - width;
			cptrDIBData = cptrDIBData + width;
		}
		
		FSWriteFork(forkRefNum, fsAtMark, 0, width * height, (void *)pDIBData, NULL );
		
		free( pDIBData );
		free( pDIBHeader );
		
		FSCloseFork(forkRefNum);
	}
}

